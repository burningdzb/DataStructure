#ifndef STACK_H
#define STACK_H
#define STACK_INIT_SIZE 100
#define STACKINCREMENT 10
#include<iostream>
using namespace std;
struct SqStack
{
   int*base;
   int*top;
   int stacksize;
};
void InitStack(SqStack&s);
bool EmptyStack(SqStack&s);
void PushStack(SqStack&s,int e);
void PopStack(SqStack&s);
void DestroyStack(SqStack&s);
#endif