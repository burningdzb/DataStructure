#ifndef LINKSTACK_H
#define LINKSTACK_H
#include<iostream>
using namespace std;
struct Node
{
	int data;
	Node*next;
};
struct Stack
{
	Node*base;
	Node*top;
	int stacksize;
};
void InitLinkStack(Stack&s);
bool EmptyLinkStack(Stack&s);
void PushLinkStack(Stack&s,int e);
void PopLinkStack(Stack&s);
void DestroyLinkList(Stack&s);
#endif