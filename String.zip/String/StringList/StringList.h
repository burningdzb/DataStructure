#ifndef STRINGLIST_H
#define STRINGLIST_H
#define MAXSIZE 80
#include<iostream>
using namespace std;
struct stringnode
{
	char cdata[MAXSIZE];
	stringnode *next;
};
class stringlist
{
private:
	stringnode *head;  //ͷ���
	stringnode *tail;  //βָ��
public:
	stringlist();
	~stringlist();
    void strinsert(char*str);
	void strprint();
	void strdestroy();
};
#endif