#include"StringFunc.h"
void StringFunc::StrAssign(const char* srcStr)
{
	int i=0;
	while(srcStr[i] != '\0')
	{
		this->a[i]=srcStr[i];
		i++;
	}
	this->a[i]='\0';
	cout<<"��ֵ��Ĵ�Ϊ"<<endl;
	cout<<this->a<<endl;
}
void StringFunc::StrCopy(const char*srcStr)
{
	int i=0;
	while(srcStr[i] != 0)
	{
		this->a[i]=srcStr[i];
		i++;
	}
	this->a[i]='\0';
	cout<<"���ƺ�Ĵ�Ϊ"<<endl;
	cout<<this->a<<endl;
}
void StringFunc::StrLength()
{
	int i=0;
	while(this->a[i] != '\0')
	{
		i++;
	}
	cout<<"�˴��ĳ���Ϊ"<<endl;
	cout<<i<<endl;
}
void StringFunc::StrConCat(char* dstStr,const char* src2)
{
	int i=0;  //iΪ���Ӻ��ַ����ĳ���
	int j=0;
	int k=0;
	while(this->a[j] != '\0')
	{
		dstStr[i]=this->a[j];
		i++;
		j++;
	}
	while(src2[k] != '\0')
	{
		dstStr[i]=src2[k];
		i++;
		k++;
	}
	dstStr[i]='\0';
	cout<<"���ӵĴ�Ϊ"<<endl;
	cout<<dstStr<<endl;
}
bool StringFunc::StrCompare(const char* src2)
{
	int i=0;
	for(int i=0;i>=0;i++)
	{
		if(this->a[i] != src2[i])
		{
			return false;
		}
		if(this->a[i] == '\0' && src2[i] == '\0')
		{
			return true;
		}
	}
}