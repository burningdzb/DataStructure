#ifndef STRINGFUNC_H
#define STRINGFUNC_H
#define MAXSIZE 300
#include<iostream>
using namespace std;
class StringFunc
{
private:
	char a[MAXSIZE];          //������󳤶�
public:
	void StrAssign(const char* srcStr);   //dstStr��Ŀ�괮��srcStr��ԭ��
	void StrCopy(const char* srcStr);
	void StrLength();
	void StrConCat(char* dstStr,const char* src2);	
	bool StrCompare(const char* src2); 
};
#endif