#include"KMP.h"
void KMP::GetNext(char*str2)
{
	int k=-1;
	int j=0;    //str2[k]Ϊǰ׺�ַ�����str2[j]Ϊ��׺�ַ���
	next[0]=-1;
	while(j < strlen(str2)-1)
	{
		if(k=-1 || str2[k] == str2[j])
		{
		    k++;
			j++;
			next[j]=k;
		}
		else
		{
		    k=next[k];
		}
	}
}
int KMP::FindIndex(char*str1,char*str2,int pos)
{
	int i=pos;
	int j=0;
	while((str1[i]&&str2[j])||j==-1)
	{
        if(str1[i] == str2[j] ||j ==-1)
		{
		    i++;
			j++;
		}
		else
		{
		    j=next[j];
		}
	}
	if(str2[j] == '\0')
	{
		return i-j;
	}
	else
		return -1;
}