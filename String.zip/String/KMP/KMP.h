#ifndef KMP_H
#define KMP_H
#define ERROR -1
#define MAXSIZE 100
#include<iostream>
using namespace std;
class KMP
{
public:
	void GetNext(char*str2);    //str1��ĸ����str2���Ӵ�
	int FindIndex(char* str1,char* str2,int pos);
private:
	int next[MAXSIZE];
};
#endif