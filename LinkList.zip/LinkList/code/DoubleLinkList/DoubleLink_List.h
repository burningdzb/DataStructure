#ifndef _DBLELINKLIST_H
#define _DBLELINKLIST_H
#include<iostream>
using namespace std;
struct Node
{
	int data;
	Node*prior;
	Node*next;
};
struct DuLinklist
{
	Node*head;
};
void CreatDbLink_List(DuLinklist*L,int size);
void PrintDbLink_List(DuLinklist*L);
void ReversePrintDbLink_List(DuLinklist*L,int size);
void InsertDbLink_List(DuLinklist*L,int ip,int e);
void InsertDbLink_List(DuLinklist*L,int iIp,int e);
void DeleteDbLink_List(DuLinklist*L,int iDp);
void DeleteDbLink_List(DuLinklist*L,int iDp);
#endif