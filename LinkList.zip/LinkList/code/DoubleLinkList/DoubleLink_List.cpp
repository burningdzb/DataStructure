#include"DoubleLink_List.h"
void CreatDbLink_List(DuLinklist*L,int size)
{                              //β�巨
	L->head=new Node;
	L->head->next=NULL;
	L->head->prior=NULL;      //����ͷ���������ǰ���ͺ������ָ��NULL
	Node*k;
	Node*p;
	k=L->head;
	cout<<"����"<<size<<"������"<<endl;
	for(int i=0;i<size;i++)
	{
	    p=new Node;
		cin>>p->data;
		getchar();
		k->next=p;
		p->next=NULL;
		p->prior=k;
		k=p;
	}
}
void PrintDbLink_List(DuLinklist*L)
{
	Node*p;
	p=L->head->next;
	p->prior=L->head;
	cout<<"�����������Ϊ"<<endl;
	while(p!=NULL)
	{
	    cout<<p->data<<" ";
		p=p->next;
	}
	cout<<endl;
}
void ReversePrintDbLink_List(DuLinklist*L,int size)
{
	Node*p;
	p=L->head;
	for(int i=0;i<size;i++)
	{
	    p=p->next;
	}
	for(int i=0;i<size;i++)
	{
		cout<<p->data<<" ";
		p=p->prior;
	}
	cout<<endl;
}
void InsertDbLink_List(DuLinklist*L,int iIp,int e)
{
    Node*p;
	Node*s;
	s=new Node;
	p=L->head;
	for(int i=0;i<iIp;i++)
	{
		p=p->next;
	}
	s->data=e;
	s->next=p->next;
	s->prior=p;
	p->next->prior=s;
	p->next=s;
	cout<<"�����Ժ�";
	PrintDbLink_List(L);
}
void DeleteDbLink_List(DuLinklist*L,int iDp)
{
	Node*p;
	p=L->head;
	for(int i=0;i<=iDp;i++)
	{
		p=p->next;
	}
	Node*k=p;
	k->prior->next=k->next;
	k->next->prior=k->prior;
	delete k;
	PrintDbLink_List(L);
}

