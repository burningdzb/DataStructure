#ifndef _LINKLIST_H
#define _LINKLIST_H
#include<iostream>
using namespace std;
struct Node   //�������
{
	Node*next;
	int data;
};
struct LinkList
{            
   Node*head; 
};
void CreatList_L(LinkList*L,int size);
void PrintList_L(LinkList*L);
void ReversePrintList_L(Node*head);
void InsertList_L(LinkList*L,int ip,int e);
void DeleteList_L(LinkList*L,int ip);
#endif